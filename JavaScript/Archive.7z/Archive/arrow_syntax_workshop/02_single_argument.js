const square = x => x * x;

const cube = x => square(x) * x;
